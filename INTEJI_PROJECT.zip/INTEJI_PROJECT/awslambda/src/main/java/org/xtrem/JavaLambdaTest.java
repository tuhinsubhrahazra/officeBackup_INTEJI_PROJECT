package org.xtrem;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import java.util.Collections;

public class JavaLambdaTest implements RequestHandler<Object,Object> {
    @Override
    public GateWayResponse handleRequest(Object input, Context context) {
        String msg = "This is from Tapas Code4, ";
        if(input != null){
            msg = msg + input;
        }
        return new GateWayResponse(
                msg,
                200,
                Collections.singletonMap("X-Powered-By","XtremSoft"),
                false
                );
    }
}
